import { BrowserRouter as Router,Route,Routes } from "react-router-dom";
import Home from "./components/main/home";
import Products from "./components/main/products";
import Checkout from "./components/main/checkout";
import Contact from "./components/main/contact"
import BookRead from "./components/main/bookread";
import BookComponent from "./components/main/bookInfo";
import Books from "./components/main/books";
import Leaderboard from "./components/main/leaderboard";
import Quiz from "./components/main/quiz";
import Congratulations from "./components/main/congratulations";
function App() { 
  return (
    <div>
       <Router>
        <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/products" element={<Products/>}/>
        {/* <Route path="/about" element={<About/>}/> */}
        {/* <Route path="/checkout" element={<Checkout/>}/>
        <Route path="/contact" element={<Contact/>}/> */}
        <Route path="/bookread" element={<BookRead/>}/>
        <Route path="/books" element={<Books/>}/>
        <Route path="/bookinfo" element={<BookComponent/>}/>
        <Route path="/takequiz" element={<Quiz/>}/>
        <Route path="/leaderboard" element={<Leaderboard/>}/>
        <Route path="/congratulations" element={<Congratulations/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
