import React, { useState, useEffect } from 'react';
import Carousel from 'react-grid-carousel';
import Card1Component from '../helper/Card1Component';
import img1 from '../../images/peer.webp'
import img2 from '../../images/cant.jpg'
import img3 from '../../images/never.jpg'
import img4 from '../../images/moh.jpg'
import img5 from '../../images/RICH.jfif'
import balance from '../../images/balance.jpg'
import { Link } from 'react-router-dom';
export default function Gallery(props) {
  const [viewportSize, setViewportSize] = useState('');
  const [numCols, setNumCols] = useState(4);
  const [cardWidth, setCardWidth] = useState('50%');

  const books = [
    { title: 'Zulm or Mohabbat ky Darmiyan', author: 'Umeraa Ahmed', year: 2018 ,image:balance},
    { title: 'Cant Hurt me', author: 'David Goggins', year: 2020,image:img2 },
    { title: 'Peer-Kamil', author: 'Umera Ahmed', year: 2019,image:img1},
    { title: 'Never Finished', author: 'David Goggin', year: 2018 ,image:img3},   
    { title: 'Rich Dad Poor Dad ', author: 'Robert Kiyosaki', year: 2018,image:img5 },

  ];

  const handleResize = () => {
    const windowWidth = window.innerWidth;

    if (windowWidth <= 576) {
      setViewportSize('xs'); // Extra small devices (phones)
      setNumCols(2);
      setCardWidth('50%');
    } else if (windowWidth <= 768) {
      setViewportSize('sm'); // Small devices (tablets)
      setNumCols(2);
      setCardWidth('50%');
    } else if (windowWidth <= 992) {
      setViewportSize('md'); // Medium devices (landscape tablets)
      setNumCols(3);
      setCardWidth('75%');
    } else if (windowWidth <= 1200) {
      setViewportSize('lg'); // Large devices (desktops)
      setNumCols(3);
      setCardWidth('75%');
    } else {
      setViewportSize('xl'); // Extra large devices (large desktops)
      setNumCols(4);
      setCardWidth('90%');
    }
  };

  useEffect(() => {
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div style={{ margin: '0 auto', maxWidth: '1200px' }}>
      <div className="d-flex align-items-center justify-content-between p-3 m-2">
          <h2>{props.heading}</h2>
        <button className="btn btn-link text-dark text-decoration-underline">
          View All
        </button>
      </div>

      <Carousel cols={numCols} rows={1} gap={10} loop>
        {books.map((book, index) => (
          <Carousel.Item key={index}>
          <Link to={`/bookinfo`} style={{textDecoration:"none"}}>
            <Card1Component
              width={cardWidth}
              title={book.title}
              author={book.author}
              year={book.year}
              img={book.image}
            />
          </Link>
        </Carousel.Item>
        ))}
      </Carousel>
    </div>
  );
}