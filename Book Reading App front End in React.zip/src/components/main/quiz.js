import Footer from '../actual/Footer';
import Header from '../actual/Header';
import partyPopper from "../../images/party-popper.gif";
import React, { useState } from "react";
import { Link } from 'react-router-dom';
import "../../css/quiz.css";


function Quiz() {
  const [showQuiz, setShowQuiz] = useState(false);
  const [correctAnswer1, setCorrectAnswer1] = useState(null);
  const [correctAnswer2, setCorrectAnswer2] = useState(null);
  const [correctAnswer3, setCorrectAnswer3] = useState(null);
  const [correctAnswer4, setCorrectAnswer4] = useState(null);
  const [correctAnswer5, setCorrectAnswer5] = useState(null);

  const [selectedAnswer1, setSelectedAnswer1] = useState(null);
  const [selectedAnswer2, setSelectedAnswer2] = useState(null);
  const [selectedAnswer3, setSelectedAnswer3] = useState(null);
  const [selectedAnswer4, setSelectedAnswer4] = useState(null);
  const [selectedAnswer5, setSelectedAnswer5] = useState(null);

  const handleTakeQuiz = () => {
    setShowQuiz(true);
  };

  const handleAnswer1 = (answer) => {
    setSelectedAnswer1(answer);
    if (answer === "correct") {
      setCorrectAnswer1(true);
    } else {
      setCorrectAnswer1(false);
    }
  };
  const handleAnswer2 = (answer) => {
    setSelectedAnswer2(answer);
    if (answer === "correct") {
      setCorrectAnswer2(true);
    } else {
      setCorrectAnswer2(false);
    }
  };
  const handleAnswer3 = (answer) => {
    setSelectedAnswer3(answer);
    if (answer === 'correct') {
      setCorrectAnswer3(true);
    } else {
      setCorrectAnswer3(false);
    }
  };
  const handleAnswer4 = (answer) => {
    setSelectedAnswer4(answer);
    if (answer === 'correct') {
      setCorrectAnswer4(true);
    } else {
      setCorrectAnswer4(false);
    }
  };
  const handleAnswer5 = (answer) => {
    setSelectedAnswer5(answer);
    if (answer === 'correct') {
      setCorrectAnswer5(true);
    } else {
      setCorrectAnswer5(false);
    }
  };

  return (
    <div>

      <Header />


      <button className="take-quiz-button" onClick={handleTakeQuiz}>Take Quiz</button>
      {showQuiz && (
        <div
          className="quiz-card"
          style={{
            backgroundColor: correctAnswer1
              ? "green"
              : selectedAnswer1
                ? "red"
                : "",
          }}
        >
          <h2 style={{ textAlign: "center" }}>سباق نمبر 1</h2>
          <h4 style={{ textAlign: "center" }}>سوال نمبر 1</h4>
          <p>کس چیز کو حل کرنے کے لئے عدالتی نظام کو مدد فراہم کی جاتی ہے؟</p>
          <ul>
            <li>
              <input
                type="radio"
                name="answer"
                value="اندرونی تنازعات"
                onClick={() => handleAnswer1("correct")}
              />
              <span>اندرونی تنازعات</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="بے رحمی"
                onClick={() => handleAnswer1("incorrect")}
              />
              <span>بے رحمی</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="ملکی خطرات"
                onClick={() => handleAnswer1("incorrect")}
              />
              <span>ملکی خطرات</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="عوام کی خوشحالی"
                onClick={() => handleAnswer1("incorrect")}
              />
              <span>عوام کی خوشحالی</span>
            </li>
          </ul>
          {correctAnswer1 && (
            <div
              className="party-poppers"
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(255, 255, 255, 0.8)",
                zIndex: 1,
              }}
            >
              <img
                src={partyPopper}
                alt="Party Popper"
                style={{
                  width: "50px",
                  height: "50px",
                  margin: "0 auto",
                  display: "block",
                }}
              />
              <p
                style={{
                  textAlign: "center",
                  fontSize: "18px",
                  color: "#333",
                }}
              >
                شکریہ! آپ نے درست جواب دیا ہے!
              </p>
            </div>
          )}
          <div
            className="party-poppers-background"
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              backgroundColor: "rgba(255, 255, 255, 0.8)",
              zIndex: -1,
            }}
          >
            <img
              src={partyPopper}
              alt="Party Popper"
              style={{
                width: "50px",
                height: "50px",
                margin: "0 auto",
                display: "block",
              }}
            />
          </div>
        </div>
      )}

      {showQuiz && (
        <div
          className="quiz-card"
          style={{
            backgroundColor: correctAnswer2
              ? "green"
              : selectedAnswer2
                ? "red"
                : "",
          }}
        >
          <h4 style={{ textAlign: "center" }}>سوال نمبر 2</h4>
          <p>کس چیز کو حل کرنے کے لئے عدالتی نظام کو مدد فراہم کی جاتی ہے؟</p>
          <ul>
            <li>
              <input
                type="radio"
                name="answer"
                value="اندرونی تنازعات"
                onClick={() => handleAnswer2("correct")}
              />
              <span>اندرونی تنازعات</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="بے رحمی"
                onClick={() => handleAnswer2("incorrect")}
              />
              <span>بے رحمی</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="ملکی خطرات"
                onClick={() => handleAnswer2("incorrect")}
              />
              <span>ملکی خطرات</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="عوام کی خوشحالی"
                onClick={() => handleAnswer2("incorrect")}
              />
              <span>عوام کی خوشحالی</span>
            </li>
          </ul>
          {correctAnswer2 && (
            <div
              className="party-poppers"
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(255, 255, 255, 0.8)",
                zIndex: 1,
              }}
            >
              <img
                src={partyPopper}
                alt="Party Popper"
                style={{
                  width: "50px",
                  height: "50px",
                  margin: "0 auto",
                  display: "block",
                }}
              />
              <p
                style={{
                  textAlign: "center",
                  fontSize: "18px",
                  color: "#333",
                }}
              >
                شکریہ! آپ نے درست جواب دیا ہے!
              </p>
            </div>
          )}
          <div
            className="party-poppers-background"
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              backgroundColor: "rgba(255, 255, 255, 0.8)",
              zIndex: -1,
            }}
          >
            <img
              src={partyPopper}
              alt="Party Popper"
              style={{
                width: "50px",
                height: "50px",
                margin: "0 auto",
                display: "block",
              }}
            />
          </div>
        </div>
      )}

      {showQuiz && (
        <div
          className="quiz-card"
          style={{
            backgroundColor: correctAnswer3
              ? "green"
              : selectedAnswer3
                ? "red"
                : "",
          }}
        >
          <h4 style={{ textAlign: "center" }}>سوال نمبر 3</h4>
          <p>کس چیز کو حل کرنے کے لئے عدالتی نظام کو مدد فراہم کی جاتی ہے؟</p>
          <ul>
            <li>
              <input
                type="radio"
                name="answer"
                value="اندرونی تنازعات"
                onClick={() => handleAnswer3("correct")}
              />
              <span>اندرونی تنازعات</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="بے رحمی"
                onClick={() => handleAnswer3("incorrect")}
              />
              <span>بے رحمی</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="ملکی خطرات"
                onClick={() => handleAnswer3("incorrect")}
              />
              <span>ملکی خطرات</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="عوام کی خوشحالی"
                onClick={() => handleAnswer3("incorrect")}
              />
              <span>عوام کی خوشحالی</span>
            </li>
          </ul>
          {correctAnswer3 && (
            <div
              className="party-poppers"
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(255, 255, 255, 0.8)",
                zIndex: 1,
              }}
            >
              <img
                src={partyPopper}
                alt="Party Popper"
                style={{
                  width: "50px",
                  height: "50px",
                  margin: "0 auto",
                  display: "block",
                }}
              />
              <p
                style={{
                  textAlign: "center",
                  fontSize: "18px",
                  color: "#333",
                }}
              >
                شکریہ! آپ نے درست جواب دیا ہے!
              </p>
            </div>
          )}
          <div
            className="party-poppers-background"
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              backgroundColor: "rgba(255, 255, 255, 0.8)",
              zIndex: -1,
            }}
          >
            <img
              src={partyPopper}
              alt="Party Popper"
              style={{
                width: "50px",
                height: "50px",
                margin: "0 auto",
                display: "block",
              }}
            />
          </div>
        </div>
      )}

      {showQuiz && (
        <div
          className="quiz-card"
          style={{
            backgroundColor: correctAnswer4
              ? "green"
              : selectedAnswer4
                ? "red"
                : "",
          }}
        >
          <h4 style={{ textAlign: "center" }}>سوال نمبر 4</h4>
          <p>کس چیز کو حل کرنے کے لئے عدالتی نظام کو مدد فراہم کی جاتی ہے؟</p>
          <ul>
            <li>
              <input
                type="radio"
                name="answer"
                value="اندرونی تنازعات"
                onClick={() => handleAnswer4("correct")}
              />
              <span>اندرونی تنازعات</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="بے رحمی"
                onClick={() => handleAnswer4("incorrect")}
              />
              <span>بے رحمی</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="ملکی خطرات"
                onClick={() => handleAnswer4("incorrect")}
              />
              <span>ملکی خطرات</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="عوام کی خوشحالی"
                onClick={() => handleAnswer4("incorrect")}
              />
              <span>عوام کی خوشحالی</span>
            </li>
          </ul>
          {correctAnswer4 && (
            <div
              className="party-poppers"
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(255, 255, 255, 0.8)",
                zIndex: 1,
              }}
            >
              <img
                src={partyPopper}
                alt="Party Popper"
                style={{
                  width: "50px",
                  height: "50px",
                  margin: "0 auto",
                  display: "block",
                }}
              />
              <p
                style={{
                  textAlign: "center",
                  fontSize: "18px",
                  color: "#333",
                }}
              >
                شکریہ! آپ نے درست جواب دیا ہے!
              </p>
            </div>
          )}
          <div
            className="party-poppers-background"
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              backgroundColor: "rgba(255, 255, 255, 0.8)",
              zIndex: -1,
            }}
          >
            <img
              src={partyPopper}
              alt="Party Popper"
              style={{
                width: "50px",
                height: "50px",
                margin: "0 auto",
                display: "block",
              }}
            />
          </div>
        </div>
      )}

      {showQuiz && (
        <div
          className="quiz-card"
          style={{
            backgroundColor: correctAnswer5
              ? "green"
              : selectedAnswer5
                ? "red"
                : "",
          }}
        >
          <h4 style={{ textAlign: "center" }}>سوال نمبر 5</h4>
          <p>کس چیز کو حل کرنے کے لئے عدالتی نظام کو مدد فراہم کی جاتی ہے؟</p>
          <ul>
            <li>
              <input
                type="radio"
                name="answer"
                value="اندرونی تنازعات"
                onClick={() => handleAnswer5("correct")}
              />
              <span>اندرونی تنازعات</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="بے رحمی"
                onClick={() => handleAnswer5("incorrect")}
              />
              <span>بے رحمی</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="ملکی خطرات"
                onClick={() => handleAnswer5("incorrect")}
              />
              <span>ملکی خطرات</span>
            </li>
            <li>
              <input
                type="radio"
                name="answer"
                value="عوام کی خوشحالی"
                onClick={() => handleAnswer5("incorrect")}
              />
              <span>عوام کی خوشحالی</span>
            </li>
          </ul>
          {correctAnswer5 && (
            <div
              className="party-poppers"
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(255, 255, 255, 0.8)",
                zIndex: 1,
              }}
            >
              <img
                src={partyPopper}
                alt="Party Popper"
                style={{
                  width: "50px",
                  height: "50px",
                  margin: "0 auto",
                  display: "block",
                }}
              />
              <p
                style={{
                  textAlign: "center",
                  fontSize: "18px",
                  color: "#333",
                }}
              >
                شکریہ! آپ نے درست جواب دیا ہے!
              </p>
            </div>
          )}
          <div
            className="party-poppers-background"
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              backgroundColor: "rgba(255, 255, 255, 0.8)",
              zIndex: -1,
            }}
          >
            <img
              src={partyPopper}
              alt="Party Popper"
              style={{
                width: "50px",
                height: "50px",
                margin: "0 auto",
                display: "block",
              }}
            />
          </div>
        </div>
      )}
      <Link to="/congratulations" style={{ textDecoration: "none" }}>
        <button className="take-quiz-button" style={{ textDecoration: "none" }}>
          End Quiz
        </button>
      </Link>
      <Footer />

    </div>
  );
}

export default Quiz;


