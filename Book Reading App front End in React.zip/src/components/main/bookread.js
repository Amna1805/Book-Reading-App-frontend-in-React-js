import Footer from '../actual/Footer';
import Header from '../actual/Header';
import '../../css/bookread.css'
export default function Bookread() {

  return (
    <div>
      <Header />
      <div className="book-reader">
        <div className="sidebar-right">

          <button className="tool-button" >Color Mode</button>
          <button className="tool-button" >Font Face</button>
          <button className="tool-button" >Font Size</button>
          <button className="tool-button" >Line Spacing</button>
          <button className="tool-button">Page Margins</button>
          <button className="tool-button" >Add Bookmark</button>

        </div>
        <div className="book-content" style={{ backgroundColor: 'white' }}>
          <div className="urdu-text-div" style={{
            height: '700px', /* adjust the height as needed */
            border: '1px solid #ddd',
            padding: '20px',
            // overflowY: 'auto'
          }}>
            <div style={{ textAlign: 'center' ,marginBottom:"60px"}}> 
            <h1 style={{ textAlign: 'center' ,margin:"20px"}}>ظلم اور محبت کے درمیان</h1>
                {/* <img src="coverpage.jpg" alt="Book Cover" class="center" > */}
                <h3>تعارف</h3>
                <p>
اگر اختیار دے دیا جائے تو میں نہیں سمجھتا کہ کوئی بھی معقول شخص اپنے خلاف کی گئی نا انصافی کو کبھی بھی شعوری طور پر اور بخوشی قبول کرتا ہے یا اُس پہ رضا مندی ظاہر کرتا ہے۔ ہم سب کسی ایسے معمولی واقعے کو، خاص کر جب کہ انصاف کا حصول مہنگا ہو یا نا انصافی کسی دوست یا گھر کے کسی فرد کی طرف سے کی گئی ہو، آسانی سے نظر انداز کر دیتے ہیں۔ لیکن ہماری ناپسندیدگی یا ناگواری صرف اُس ناانصافی تک محدود نہیں جو ہماری ذات سے زوار کھی گئی ہو بلکہ ہمیں یہ احساس اس وقت بھی ہوتا ہے جب نا انصافی کسی دوسرے شخص جگہ ، ادارے، حتی کہ کسی ایسے نظریے کے ساتھ ہو جس سے ہم خود کو متعلق سمجھتے ہوں یا اُس کے ساتھ بڑے ہوں۔ یہ بھی ایک حقیقت ہے کہ ہم انصاف کو پسندکرتےہیں ور اسے فوقیت دیتے ہیں۔ </p>
 خاص کر اُس وقت جب انصاف ہمارے ساتھ ہو یا ہمارے لیے ہوا ہو۔ ہم ایسی ہی فوقیت دوسرے لوگوں، جگہوں، اداروں اور نظریوں کے لیے بھی دیتے ہیں جو ہم متعلق ہوں یا بڑے ہوں۔ یہ عمومی تصورات آفاقی طور پر اتنے بنیادی اور اہم ہیں کہ ہر ملک اور افراد کی منظم جماعتوں نے ایسے قوانین کے مجموعے کو خوب سے خوب تر بنایا یا اپنایا جس سے انصاف کا ایک نظام مہیا کیا جائے اور اسے قائم رکھا جائے۔ یہ نظام خاص طور پر غلط اقدامات کے خلاف تحفظ بھی فراہم کرتا ہے اور اندرونی تنازعات کو حل کرنے کے راستے بھی۔ یہاں تک کہ گھریلو اور ذاتی سطح پر بھی ہم ایسے اصول اور سوچ پیدا کرنے اور اُن پر اپک عمل پیرا ہونے پر مائل ہوتے ہیں جن سے ایک دوسرے کے ساتھ ناانصافی سے بچا جا سکے۔</div>
 <a href="/takequiz" class="btn btn-primary  center">Take a Quiz</a>
         <div className="pagination">
    <button className="prev-button">
      <i className="fa fa-chevron-left" aria-hidden="true"></i>
    </button>
    <div className="page-number">Page 1 of 5</div>
    <button className="next-button">
      <i className="fa fa-chevron-right" aria-hidden="true"></i>
    </button>
  </div>
          </div>
        </div>
        <div className="sidebar-left">
          <ul>
            <li><a href="#chapter-1">سباق1: تعارف</a></li>
            <li><a href="#chapter-2" className='disable'>سباق 2: تاریخ</a></li>
            <li><a href="#chapter-3" className='disable'>سباق 3: ثقافت</a></li>
            <li><a href="#chapter-4" className='disable'>سباق 4: مذہب</a></li>
            <li><a href="#chapter-5" className='disable'>سباق 5: نتیجہ</a></li>
          </ul>
        </div>

      </div>
      <Footer />
    </div>
  );
}

