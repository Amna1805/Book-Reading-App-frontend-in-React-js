import Footer from '../actual/Footer';
import Header from '../actual/Header';
import moh from '../../images/moh.jpg';
import '../../css/Book.css';
import { Link } from 'react-router-dom';
import FilterBar from '../actual/Filterbar';
export default function Books(){
  return (
    <div>
      <Header/>
      <FilterBar/>
      <Footer/>
    </div>
  );
}


