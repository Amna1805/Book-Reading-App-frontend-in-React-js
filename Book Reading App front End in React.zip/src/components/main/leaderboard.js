import Footer from '../actual/Footer';
import Header from '../actual/Header';
import React from 'react';
import '../../css/leaderboard.css';
import image1 from '../../images/person 1.jpg';
import image2 from '../../images/person 2.jpg';
import image3 from '../../images/person 3.jpg';

export default function Leaderboard() {
  const leaderboardData = [
    { name: "John Doe", points: 100, avatar: [image1] },
    { name: "Jane Doe", points: 90, avatar: [image2] },
    { name: "Bob Smith", points: 80, avatar: [image3] },
    { name: "Alice Johnson", points: 70 },
    { name: "Mike Brown", points: 60 },
    { name: "Emily Davis", points: 50 }
  ];

  const top3 = leaderboardData.sort((a, b) => b.points - a.points).slice(0, 3);
  const otherUsers = leaderboardData.sort((a, b) => b.points - a.points).slice(3);

  return (
    <div>
      <Header />
      <div className="leaderboard-container">
        <h3 style={{textAlign:"center"}}>Welcome to Leaderboard</h3>
        <div className="leaderboard">
          {top3.map((item, index) => (
            <div
              className={index === 0 ? "leaderboard-item first" : index === 1 ? "leaderboard-item second" : "leaderboard-item third"}
              key={index}
            >
              <img src={item.avatar} alt={`${index + 1}st place` } className="avatar" />
              <h2>{index + 1}st</h2>
              <p><span>{item.name}</span></p>
              <p><span>{item.points}</span></p>
              <div className="bar" style={{ height: `${item.points}px`, backgroundColor: '#007bff' }} />
            </div>
          ))}
        </div>
        <div className="other-users">
  <h2 style={{fontSize:"20px",margin:"10px"}}>My Points</h2>
  <table className="table-style">
    <thead>
      <tr>
        <th>Name</th>
        <th>Points</th>
      </tr>
    </thead>
    <tbody>
      <tr> <td>Amna Muzaffar</td>
          <td>50</td></tr>
          <tr> <td>Sameer Khan</td>
          <td>50</td></tr>
         
     
    </tbody>
  </table>
</div>
        <div className="other-users">
        <h2 style={{fontSize:"20px",margin:"10px"}}>Other Users</h2>
  <table className="table-style">
    <thead>
      <tr>
        <th>Name</th>
        <th>Points</th>
      </tr>
    </thead>
    <tbody>
      {otherUsers.map((item, index) => (
        <tr key={index}>
          <td>{item.name}</td>
          <td>{item.points}</td>
        </tr>
      ))}
    </tbody>
  </table>
</div>
      </div>
      <Footer />
    </div>
  );
}