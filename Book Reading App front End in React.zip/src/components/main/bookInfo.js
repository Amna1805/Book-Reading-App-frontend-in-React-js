import Footer from '../actual/Footer';
import Header from '../actual/Header';
import moh from '../../images/moh.jpg';
import '../../css/Book.css';
import { Link } from 'react-router-dom';
import img from '../../images/what.png'
import balance from '../../images/balance.jpg'
import Card1ListComponent from '../helper/Card1ListComponent'
export default function BookComponent() {
  return (
    <div>
      <Header />
      <div className="book-component">
      <Card1ListComponent
  style={{
    margin: '20px'
  }}
  width={'800px'}
  title={"Zulm or Mohabbat ky Darmiyan"}
  author={"Umera Ahmed"}
  year={"2020"}
  img={balance}
/>
                  
        <div className="book-details">
          <div className="book-description">
            <h2>What's Inside the Book?</h2>
            <img src={img} alt="nf" style={{width:"300px",height:"200px"}}></img>
          </div>
          <div className="what-you-will-learn">
            <h3>What You Will Learn</h3>
            <ul>
              <li><i className="fa fa-check"></i> Lorem ipsum dolor sit amet</li>
              <li><i className="fa fa-check"></i> Consectetur adipiscing elit</li>
              <li><i className="fa fa-check"></i> Sed do eiusmod tempor incididunt</li>
            </ul>
          </div>
          <div className="book-quote">
            <blockquote>
              <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."</p>
              <cite style={{ color: 'red' }}>~Author Name</cite>
            </blockquote>
          </div>
          <div className="read-button">
            <Link to={`/bookread`}><button>Read</button></Link>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}