import CheckoutComp from "../actual/CheckoutComponent"
export default function checkout(){
  return (
    <div>
      <CheckoutComp/>
    </div>
  );
}

