import Footer from '../actual/Footer';
import Header from '../actual/Header';
import moh from '../../images/moh.jpg';
import '../../css/congo.css';
import party from '../../images/party-popper.gif'
import { Link } from 'react-router-dom';

export default function Congratulations() {
  return (
    <div>
      <Header />
      <div className="congratulations-container">
        <div className="congratulations-content">
          <h3 className="congratulations-title">Congratulations!</h3>
          <img src={party}  style={{width:"100px", height:"100px"}} alt="Party Popper" className="party-popper" />
          <p className="congratulations-text">You've completed this chapter! You got 4 points out of 5</p>
        </div>
        <Link to="/bookread">
          <button className="read-next-chapter-button">Read Next Chapter</button>
        </Link>
        <Link to="/leaderboard">
          <button className="read-next-chapter-button m-2">View LeaderBoard</button>
        </Link>
      </div>
      <Footer />
    </div>
  );
}