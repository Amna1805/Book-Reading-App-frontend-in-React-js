import React from 'react';
import styles from '../../css/myfile.module.css';
import slider2 from '../../images/slider2.jpg';

function Category1Component({ width, height ,name,img}) {
  const circleStyle = {
    width: width,
    height: height,
    borderRadius: '50%',
    overflow: 'hidden',
  };

  return (
    <div className={`category-item  ${styles.categoryItem}`}>
      <div className={`category-circle ${styles.categoryCircle}`} style={circleStyle}>
        <img src={img} alt="Category" className={`category-image ${styles.categoryImage}`} />
      </div>
      <div className={`category-title ${styles.categoryTitle}`}>
       {name}
      </div>
    </div>
  );
}

export default Category1Component;
